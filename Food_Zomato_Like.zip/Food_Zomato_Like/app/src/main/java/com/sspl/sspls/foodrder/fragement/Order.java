package com.sspl.sspls.foodrder.fragement;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.sspl.sspls.foodrder.R;
public class Order extends Fragment {
    View root;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {

        root= inflater.inflate(R.layout.fragment_order, container, false);

        return root;
    }


}

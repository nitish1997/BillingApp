package com.sspl.sspls.foodrder.activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.OptionalPendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.sspl.sspls.foodrder.R;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
public class Login extends AppCompatActivity implements View.OnClickListener,GoogleApiClient.OnConnectionFailedListener {
TextView tv_google,tv_btnSend;
EditText ed_number;
private GoogleApiClient mGoogleApiClient;
    SignInButton signInButton;
    private static final int RC_SIGN_IN = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().hide();
        initView();
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .enableAutoManage(this, this)
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .build();
        tv_google.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signIn();
            }
        });
    }
    @Override
    public void onStart() {
        super.onStart();
        OptionalPendingResult<GoogleSignInResult> opr = Auth.GoogleSignInApi.silentSignIn(mGoogleApiClient);
        if (opr.isDone()) {
            GoogleSignInResult result = opr.get();

        } else {
            opr.setResultCallback(new ResultCallback<GoogleSignInResult>() {
                @Override
                public void onResult(GoogleSignInResult googleSignInResult) {

                }
            });
        }
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.sign_in_button:
                signIn();
                break;
            case R.id.google:
                signInButton.performClick();
                break;
            }
    }
    private void signIn() {
        startActivity(new Intent(Login.this,Dashboard.class));
//        System.out.println("your Sign in method: ");
//        Intent signInIntent = Auth.GoogleSignInApi.getSignInIntent(mGoogleApiClient);
//        startActivityForResult(signInIntent, RC_SIGN_IN);
    }
    private void handleSignInResult(GoogleSignInResult result) {
        if (result.isSuccess())
        {
            startActivity(new Intent(Login.this,Dashboard.class));
//            Toast.makeText(Login.this,"success",Toast.LENGTH_SHORT).show();
//            System.out.println("result is success ");
//            GoogleSignInAccount acct = result.getSignInAccount();
//            String personName = acct.getDisplayName();
//            String email1 = acct.getEmail();
//            updateUI(true,personName,email1);
        }
        else
        {
            System.out.println("======Unsuccess=="+result);
        }
    }
    public void updateUI(boolean isSignedIn,String name,String email) {
        if(isSignedIn)
        {
            startActivity(new Intent(Login.this,Dashboard.class));
        }
     }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_SIGN_IN) {
            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
            handleSignInResult(result);
        }
    }
    private void initView() {
        signInButton = findViewById(R.id.sign_in_button);
        tv_google=findViewById(R.id.google);
        tv_btnSend=findViewById(R.id.btnSend);
        ed_number=findViewById(R.id.number);
        signInButton.setOnClickListener(this);
        tv_google.setOnClickListener(this);
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        Toast.makeText(Login.this,"fail---"+connectionResult,Toast.LENGTH_SHORT).show();
    }
}
